#!/usr/bin/env node
require('./cli-example.js');
